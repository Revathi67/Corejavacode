package mypack;
import java.awt.*;
import java .awt.event.*;
import java.sql.*;

import javax.swing.*;

import com.mysql.jdbc.PreparedStatement;
public class Takeorder implements ActionListener  {
	


	JFrame frame;
	JLabel L1,L2,L3,L4,L5,L6,L7,L8;
	JButton B1;
	JTextField t4,t6;
		Takeorder()
		{
	  
		frame=new JFrame("order form");
		frame.setSize(700,700);
		frame.setLayout(null);
		 frame.setLocationRelativeTo(null);
	    frame.setContentPane(new JLabel(new ImageIcon("images/img5.jfif")));
		//frame.setBackground(new Color(51,153,102));
		frame.setForeground(Color.black);
		L1=new JLabel("ORDER FORM"); 
		L1.setFont(new Font("Comic Sans",Font.BOLD,13));
		L1.setBounds(175,30,100,50);
	    frame.add(L1);
	    L2=new JLabel("Name:");
	    L2.setBounds(70,100,80,25);
	    frame.add(L2);
	    JTextField t1=new JTextField(15);
	    t1.setBounds(190,100,165,25);
	    frame.add(t1);
	    L3=new JLabel("Contact no:");
	    L3.setBounds(70,130,80,25);
	    frame.add(L3);
	    JTextField t2=new JTextField(13);
	    t2.setBounds(190,130,165,25);
	    frame.add(t2);
	    L4=new JLabel("Address:");
	    frame.add(L4);
	    L4.setBounds(70,160,80,25);
	    JTextField t3=new JTextField(15);
	    t3.setBounds(190,160,165,25);
	    frame.add(t3);
	    L5=new JLabel("Productid:");
	    L5.setBounds(70,190,80,25);
	    frame.add(L5);
	     t4=new JTextField(10);
	    t4.setBounds(190,190,165,25);
	    frame.add(t4);
	   
	    L7=new JLabel("Quantity");
	    L7.setBounds(70,310,80,25);
	    frame.add(L7);
	     t6=new JTextField(10);
	    t6.setBounds(190,310,165,25);
	    frame.add(t6);
	  
	   B1=new JButton("Place order");
	   B1.setBounds(175,440,100,45);
	   B1.setBackground(new Color(255,235,205));
	   B1.addActionListener(this);
	   
	   frame.add(B1);
	   
	  
	  
		frame.setResizable(false);
		frame.setVisible(true);   }
		public void actionPerformed(ActionEvent e) {
			JButton B = (JButton)e.getSource();
int a=Integer.parseInt(t4.getText());
int q=Integer.parseInt(t6.getText());

			if(B.getActionCommand().equals("Place order"))
			{
				//System.out.println(a);
				//System.out.println(q);
				new Takeorder1(a,q);
				JOptionPane.showMessageDialog(null, "Thankyou for ordering..delivered soon!");
		   new win();
			}
	
		}
	}


