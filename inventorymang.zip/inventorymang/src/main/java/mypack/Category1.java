package mypack;

public class Category1 {

}
