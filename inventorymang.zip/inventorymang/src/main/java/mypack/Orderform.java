package mypack;

import java.awt.*;
import java .awt.event.*;

import javax.swing.*;

public class Orderform implements ActionListener 
{ 
JFrame frame;
JLabel L1,L2,L3,L4,L5,L6,L7,L8;
JButton B1,B2;
JTextField t6,t7;
	Orderform()
	
	{
  
	frame=new JFrame("order form");
	frame.setSize(700,700);
	frame.setLayout(null);
    frame.setContentPane(new JLabel(new ImageIcon("images/img4.jfif")));
	frame.setBackground(new Color(51,153,102));
	frame.setForeground(Color.black);
	frame.setLocationRelativeTo(null);
	L1=new JLabel("ORDER FORM"); 
	L1.setFont(new Font("Comic Sans",Font.BOLD,13));
	L1.setBounds(175,30,100,50);
    frame.add(L1);
    L2=new JLabel("Name:");
    L2.setBounds(180,100,80,25);
    frame.add(L2);
    JTextField t1=new JTextField(15);
    t1.setBounds(300,100,165,25);
    frame.add(t1);
    L3=new JLabel("Contact no:");
    L3.setBounds(180,130,80,25);
    frame.add(L3);
    JTextField t2=new JTextField(13);
    t2.setBounds(300,130,165,25);
    frame.add(t2);
    L4=new JLabel("Store name:");
    frame.add(L4);
    L4.setBounds(180,160,80,25);
    JTextField t3=new JTextField(15);
    t3.setBounds(300,160,165,25);
    frame.add(t3);
    L5=new JLabel("Address:");
    L5.setBounds(180,190,80,25);
    frame.add(L5);
    JTextField t4=new JTextField(10);
    t4.setBounds(300,190,165,55);
    frame.add(t4);
   L6=new JLabel("Companyid");
   L6.setBounds(180,260,80,25);
    frame.add(L6);
    JTextField t5=new JTextField(15);
    t5.setBounds(300,260,165,25);
    frame.add(t5);
    L7=new JLabel("Productid:");
    L7.setBounds(180,310,80,25);
    frame.add(L7);
     t6=new JTextField(10);
    t6.setBounds(300,310,165,25);
    frame.add(t6);
    L8=new JLabel("Quantity");
    L8.setBounds(180,370,80,25);
    frame.add(L8);
     t7=new JTextField(10);
    t7.setBounds(300,370,165,25);
    frame.add(t7);
   B1=new JButton("Place order");
   B1.setBounds(190,440,100,45);
   B1.setBackground(new Color(255,235,205));
   B1.addActionListener(this);
   frame.add(B1);
   B2=new JButton("Cancel");
   B2.setBounds(320,440,100,45);
   B2.setBackground(new Color(255,235,205));
   B2.addActionListener(this);
   frame.add(B2);
  
	frame.setResizable(false);
	frame.setVisible(true);   }
	public void actionPerformed(ActionEvent e) {
		JButton B = (JButton)e.getSource();
		if(B.getActionCommand().equals("Place order"))
		{

			int a=Integer.parseInt(t6.getText());
			int q=Integer.parseInt(t7.getText());

						if(B.getActionCommand().equals("Place order"))
						{
							
							new Takeorder2(a,q);
			               JOptionPane.showMessageDialog(null, "Order Confirm..");
	                        new win();
		}
		if(B.getActionCommand().equals("Cancel"))
		{
            new win();
	
		}
	}
}
}
