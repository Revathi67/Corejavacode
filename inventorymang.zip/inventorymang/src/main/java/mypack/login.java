package mypack;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.*;
public class login implements ActionListener {
	 JFrame frame;
	   JLabel L1;
	   JButton B1,B2,B3;
	   JPanel P;
	   
login()
{
	frame=new JFrame("Admin purpose");
	frame.setSize(700,700);
    frame.setBackground(new Color(204,204,255));
    frame.setContentPane(new JLabel(new ImageIcon("images/img3.jfif")));
    frame.setLocationRelativeTo(null);
	L1=new JLabel();
	L1.setBounds(55,25,45,75);
	L1.setSize(450,450);
	frame.add(L1);
 
	 B1=new JButton("Addorder");
	    B1.setBounds(235,92,100,55);
	    frame.add(B1);
	    B1.addActionListener(this);
	    B1.setForeground(Color.white);
	    B1.setFont(new Font("Fantasy",Font.BOLD,13));
	    B1.setBackground(new Color(0,51,102));
    B2=new JButton("Category");
    B2.setBounds(365,92,100,55);
    frame.add(B2);
    B2.addActionListener(this);
    B2.setForeground(Color.white);
    B2.setFont(new Font("Fantasy",Font.BOLD,13));
    B2.setBackground(new Color(0,51,102));
    frame.setResizable(false);
	frame.setVisible(true);
}
	public void actionPerformed(ActionEvent e) 
	{
     JButton B = (JButton)e.getSource();
		
		if(B.getActionCommand().equals("Addorder"))
		{
			this.frame.dispose();
             new Orderform();
		
		}
		else if (B.getActionCommand().equals("Category"))
		{ 
			this.frame.dispose();
			new demo();
		}
		
	}
	

}
