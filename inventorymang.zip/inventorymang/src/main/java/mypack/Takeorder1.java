package mypack;
import java.sql.*;

import com.mysql.*;
public class Takeorder1 extends Takeorder {
	PreparedStatement ps=null;   // for adding / updating records prepared interface is used	  
	Connection con=null;
	Statement st = null;
	ResultSet re = null;
	
	//temp value
	int a ;
	Takeorder1(){
		
	}
	Takeorder1(int b,int c)
	{
//System.out.println(b+""+c);
		try
		{
			
		Class.forName("com.mysql.jdbc.Driver");
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/corejavaprj","root","");
		st = con.createStatement();	
		re = st.executeQuery("SELECT * FROM `inventory` WHERE `prid`="+b);

		while(re.next())
		{
			
			//minus  r qunatity and store in a variable
			a=(re.getInt("qty")-c);

			
			
		}
	
		ps = con.prepareStatement("UPDATE `inventory` SET `qty` = ? WHERE `inventory`.`prid` = ?");
		
		ps.setInt(1, a);
		ps.setInt(2,b);
		
		boolean d = ps.execute();
		con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
