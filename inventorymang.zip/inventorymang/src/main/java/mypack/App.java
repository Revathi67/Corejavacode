 package mypack;
import javax.swing.*;
import java.awt.*;
import java .awt.Event.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
 class win implements ActionListener
 {
   JFrame frame;
   JLabel L1;
   JButton B1,B2;
   Statement st=null;   // giving a query
	ResultSet rs=null;   // fetch records and put in buffer
	Connection con=null;
   
 win()
 {
		frame=new JFrame("inventory management");
		frame.setSize(700,700);
		frame.setLayout(null);
		frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		
		
	    //frame.setBackground(new Color(71,96,84));
        frame.setContentPane(new JLabel(new ImageIcon("images/download.jfif")));
	
		L1=new JLabel();
		//L1.setSize(450,450);
		frame.add(L1);
		JLabel L2=new JLabel("RKS");
		JLabel L3=new JLabel("Shop");
		L3.setBounds(345,13,100,50);
		L3.setFont(new Font("Comic Sans",Font.BOLD,35));
		L3.setForeground(new Color(128,42,42));
		frame.add(L3);
		L2.setBounds(250,13,100,50);
		L2.setFont(new Font("Comic Sans",Font.BOLD,35));
		L2.setForeground(new Color(128,42,42));
		frame.add(L2);
		B1=new JButton("ADMIN");
		B1.setBounds(220,588,100,50);
		B1.setFont(new Font("Comic Sans",Font.ITALIC,15));
		B1.setForeground(Color.black);
		B1.setBackground(Color.pink);
		frame.add(B1);
		B2=new JButton("Customer");
		B2.setBounds(370,588,100,50);
		B2.setFont(new Font("Comic Sans",Font.ITALIC,15));
		B2.setForeground(Color.black);
		B2.setBackground(Color.pink);
		frame.add(B2);
		B1.addActionListener(this);
		B2.addActionListener(this);
		frame.setResizable(false);
		frame.setVisible(true);
		
	}
public void actionPerformed(ActionEvent e) 
{
		JButton B = (JButton)e.getSource();
		
		if(B.getActionCommand().equals("ADMIN"))
		{
            this.frame.dispose();
			new UserForm();	
		}
		else if (B.getActionCommand().equals("Customer"))
		{
			
		   new Category();	
		}
		
 }
}
 public class App 
 {
     public static void main( String[] args )
     {
       new win();
       
     }
 }