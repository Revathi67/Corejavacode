package mypack;
	import java.awt.Color;
	import java.awt.FlowLayout;
	import java.awt.event.ActionEvent;
	import java.awt.event.ActionListener;
	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.ResultSet;
	import java.sql.Statement;

	import javax.swing.JButton;
	import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
	import javax.swing.JScrollPane;
	import javax.swing.JTable;
	public class Categorycall implements ActionListener
	{
		Categorycall()
		{
	            JFrame F;
				JPanel P;
				JButton B3,b3;
				JScrollPane jsp;
				JTable t;
				
				F = new JFrame("Customer Details");
				F.setLocationRelativeTo(null);
				F.setLayout(new FlowLayout(FlowLayout.CENTER));
				F.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				
				B3=new JButton("Place order");
			     B3.setBounds(365,500,100,45);
			     B3.setBackground(new Color(255,235,205));
				 B3.addActionListener(this);
				 
				 b3=new JButton("Back");
			     b3.setBounds(365,500,100,45);
			     b3.setBackground(new Color(255,235,205));
				 b3.addActionListener(this);
				
				P = new JPanel();
			
			    P.setBackground(Color.GREEN);		
		
				F.add(P);
				
				F.add(B3);
			 F.add(b3);
				String colmn[] ={"Productid","Product name","Quantity ","Price"};
				String data[][] = new String[50][4];
				
				int i=0;
				Statement st=null;   // giving a query
				ResultSet rs=null;   // fetch records and put in buffer
				Connection con=null;
				try
				{
				Class.forName("com.mysql.jdbc.Driver");
				//Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/corejavaprj","root","1234") 
				
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/corejavaprj","root","");
				st = con.createStatement(); // call back method, it provide/ run query at backend
				rs = st.executeQuery("select * from inventory");
			
				while(rs.next())
				{
				
				data[i][0]=Integer.toString(rs.getInt("prid"));
				data[i][1]=rs.getString("prnm");
				data[i][2]=Integer.toString(rs.getInt("qty"));
				data[i][3]=Integer.toString(rs.getInt("price"));
				
				i++;
				}
				t=new JTable(data,colmn);
				jsp=new JScrollPane(t); 
				P.add(jsp);
			    F.setSize(700, 700);				
				F.setVisible(true);
		
				}																	
				catch(Exception e1)
				{
					e1.printStackTrace();
				}
	}

		public void actionPerformed(ActionEvent e) {
		     JButton B = (JButton)e.getSource();
				
				
		
			if(B.getActionCommand().equals("Place order"))
			{
				JOptionPane.showMessageDialog(null, "plz order by productid");
			new Takeorder();
			}
			if(B.getActionCommand().equals("Back"))
			{
				
	                   new win();
		   }


		}
	}
