package mypack;
import java.sql.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import java .awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Category implements ActionListener  {
	JFrame f;
   JPanel contentpane;
JButton B2,B3;

	public Category() 
	{
		
		f=new JFrame();
		f.setTitle("show data");
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setBounds(100, 100, 589, 381);

		f.setSize(700,700);
		f.setLocationRelativeTo(null);
		contentpane=new JPanel();
		contentpane.setBorder(new EmptyBorder(5,5,5,5));
		f.setContentPane(contentpane);
		contentpane.setLayout(null);
		f.setContentPane(new JLabel(new ImageIcon("images/img6.jfif")));
		
		JButton b1=new JButton("Category");
		b1.setFont(new Font("Tahoma",Font.ITALIC,14));
		b1.setBounds(350,16,128,35);
		f.add(b1);
		b1.addActionListener(this);	
		JButton b2=new JButton("Cancel");
		b2.setFont(new Font("Tahoma",Font.ITALIC,14));
		b2.setBounds(490,16,128,35);
		f.add(b2);
		b2.addActionListener(this);	
		JLabel l2=new JLabel("Reviews:");
		l2.setBounds(190,245,128,55);
		l2.setFont(new Font("Tahoma",Font.BOLD,25));
		JLabel l3=new JLabel("1.Deliverd Soon");
		l3.setBounds(220,285,128,55);
		l3.setForeground(Color.BLUE);
		l3.setFont(new Font("Tahoma",Font.BOLD,14));
		JLabel l4=new JLabel("2.Good quality");
		l4.setBounds(220,305,128,55);
		l4.setForeground(Color.BLUE);
		l4.setFont(new Font("Tahoma",Font.BOLD,14));
		JLabel l5=new JLabel("3.Return option");
		l5.setBounds(220,325,128,55);
		l5.setForeground(Color.BLUE);
		l5.setFont(new Font("Tahoma",Font.BOLD,14));
		JLabel l8=new JLabel("availble");
		l8.setBounds(250,345,128,55);
		l8.setForeground(Color.BLUE);
		l8.setFont(new Font("Tahoma",Font.BOLD,14));
		JLabel l6=new JLabel("Address:");
		l6.setBounds(190,420,128,55);
		l6.setForeground(Color.BLACK);
		l6.setFont(new Font("Tahoma",Font.BOLD,25));
		JLabel l7=new JLabel("NO-6,green");
		l7.setBounds(240,450,128,55);
		l7.setForeground(Color.BLUE);
		l7.setFont(new Font("Tahoma",Font.BOLD,14));
		JLabel l9=new JLabel(" road,chennai-17.");
		l9.setBounds(250,466,128,55);
		l9.setForeground(Color.BLUE);
		l9.setFont(new Font("Tahoma",Font.BOLD,14));

		b2.setBackground(new Color(51,153,102));
	  b1.setBackground(new Color(51,153,102));
	  //JLabel.l5=new JLabel(("images/img3.jfif")); 
	//f.add(l5);
	  

		f.add(l3);
		f.add(l2);
		f.add(l4);
		f.add(l5);
		f.add(l6);
		f.add(l7);
		f.add(l8);
		f.add(l9);
		f.setResizable(false);
	    f.setVisible(true);
	}
	

	public void actionPerformed(ActionEvent e)
	{
		JButton B = (JButton)e.getSource();
		if(B.getActionCommand().equals("Category"))
		{
			
         new Categorycall();
	   }
		if(B.getActionCommand().equals("Cancel"))
		{
			
      new win();
	   }

}
}