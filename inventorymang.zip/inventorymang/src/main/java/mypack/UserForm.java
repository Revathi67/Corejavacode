package mypack;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class UserForm implements ActionListener{
	private static JFrame F;
	private static JLabel L1,L2,L3;
	private static JPanel P;
	private static JButton B1;
	private static JTextField userText ;
	private static JPasswordField Passwordtext;
	
	UserForm()
	{
		F = new JFrame("USERFORM");
       
    	F.setSize(700,700);
    	P = new JPanel();		
		F.add(P);		
		F.setLocationRelativeTo(null);
		
        P.setLayout(null);

	    P.setBackground(new Color(255,199,174));
 
        L1=new JLabel("UserName");
	    L1.setBounds(170,240,80,25);
	    L1.setFont(new Font("Comic Sans",Font.BOLD,15));
	    L1.setForeground(Color.black);
	    P.add(L1);
	    userText=new JTextField(20);
	    userText.setBounds(280,240,165,25);
	    P.add(userText);
	    L2=new JLabel("Password");
	    L2.setBounds(170,300,80,25);
	    L2.setFont(new Font("Comic Sans",Font.BOLD,15));
	    L2.setForeground(Color.black);
	    P.add(L2);
	    Passwordtext=new JPasswordField();
	    Passwordtext.setBounds(280,300,165,25);
	    
	    P.add(Passwordtext);
	    B1=new JButton("Login");
	    B1.setBounds(290,400,100,35);
		B1.setFont(new Font("Comic Sans",Font.ITALIC,15));
		B1.setForeground(Color.black);
		B1.setBackground(new Color(255,199,174));
		B1.addActionListener(this);
        P.add(B1);
        
        F.setResizable(false);
        F.setVisible(true);
	}


	public void actionPerformed(ActionEvent e) {
		String user=userText.getText();
		String password=Passwordtext.getText();
		
			JButton B = (JButton)e.getSource();
			if(B.getActionCommand().equals("Login"))
			{
				if(user.equals("Revathi")&& password.equals("12345"))
				{ 
                new login();	
			    }
		
		else
		{
			JOptionPane.showMessageDialog(null, "Invalid username and password");
		}
			}
	}
}
